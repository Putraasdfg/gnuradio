Install GnuRadio Companion
Attach both HackRF and RTL-SDR to your Computer.
Run both Flowgraph
